clc all
clear all
Tag = load(sprintf('..\\demo\\AHH9662.mat'));
Tag = cell2mat(struct2cell(Tag));
src = Tag;
fs = 1000000; %Sampling frequency  
N = length(src);n=0:N-1;
freq = n*fs/N;
f = abs(fft(src,N).*2/N);
x = f(1:N/2);  % frequency amplitude
freq = freq(1:N/2)';  %frequency value

%********************************Calculate frequency domain eigenvalues*****************************
MF = mean(x); %Average frequency
FC = sum(freq.*x)/sum(x);%Center of gravity frequency
RMSF = sqrt(sum([freq.^2].*x)/sum(x));%Root mean square of frequency
RVF = sqrt(sum([(freq-FC).^2].*x)/sum(x));%Frequency standard deviation
   




