% % % %%% Proposed cross-validation, where the class of attacking tags are not in a training set %%%%%%
clear
clc all

Tag_A = load(sprintf(('..\demo\\..'));
Tag_B = load(sprintf('..\demo\\..'));


Tag_A = cell2mat(struct2cell(Tag_A));
Tag_B = cell2mat(struct2cell(Tag_B));

features = [1:28];%Select the number of features

Len = 20;
Space = 20;
Fold = 5;
Mento = 100;

NumTh = 2000; % the threshold for a max or min criterion
%
f = waitbar(0,'Please wait...');
%

%%%%%%%% 5-fold cross validation %%%
for mento = 1:Mento
    
    str=['Please wait...',num2str(100*(mento-1)/Mento),'%'];
    waitbar((mento-1)/Mento,f,str);
    
    IndA = randperm(20);
    IndB = randperm(20);
    
    %%% Training set %%%%%%
    NumSub_A = [IndA(1:16)
        IndA(5:20)
        IndA(1:4) IndA(9:20)
        IndA(1:8) IndA(13:20)
        IndA(1:12) IndA(17:20)];
    
    NumSub_B = [IndB(1:16)
        IndB(5:20)
        IndB(1:4) IndB(9:20)
        IndB(1:8) IndB(13:20)
        IndB(1:12) IndB(17:20)];
    
    %%% Testing set %%%%%%
    NumSub_A_t = [ IndA(17:20)
        IndA(1:4)
        IndA(5:8)
        IndA(9:12)
        IndA(13:16) ];
    
    NumSub_B_t = [ IndB(17:20)
        IndB(1:4)
        IndB(5:8)
        IndB(9:12)
        IndB(13:16) ];
    
    Label_Exp(1:size(NumSub_A_t ,2), :) = {'authentic'};
    Label_Exp(size(NumSub_A_t ,2)+1:size(NumSub_A_t ,2)+size(NumSub_B_t ,2),:) = {'counterfeit'};
    
    
    for   fold=1:Fold
        
        %%% Training set %%%%%%
        NumSub_authentic = NumSub_A(fold, :);
        NumSub_counterfeit   = NumSub_B(fold, :);
        
        %%% Testing set %%%%%%
        NumSub_authentic_t = NumSub_A_t(fold, :);
        NumSub_counterfeit_t = NumSub_B_t(fold, :) ;
        
        %% the  Pearson correlations for training subjects
        Subj_PearCorr_authentic = Tag_A(NumSub_authentic,:);
        Subj_PearCorr_counterfeit = Tag_B(NumSub_counterfeit,:);
        
        
 
        % %                 % % %%% For Extraction %%%%%%
        Coordi_authentic=[];
        Coordi_authentic =  Tag_A(NumSub_MCI,p);
        Coordi_authentic=[];
        Coordi_authentic(1:3,:)  = Tag_C(NumSub_NC(1:3),features);
        Coordi_authentic(4:6,:)  = Tag_D(NumSub_NC(4:6),features);
        Coordi_authentic(7:9,:)  = Tag_E(NumSub_NC(7:9),features);
        Coordi_authentic(10:12,:)  = Tag_F(NumSub_NC(10:12),features);
        Coordi_authentic(13:15,:)  = Tag_G(NumSub_NC(13:15),features);
        randx1=randi(5,1);
        if randx1==1
            Coordi_authentic(16,:)  = Tag_C(NumSub_NC(16),features);
        elseif randx1==2
            Coordi_authentic(16,:)  =Tag_ D(NumSub_NC(16),features);
        elseif randx1==3
            Coordi_authentic(16,:)  = Tag_E(NumSub_NC(16),features);
        elseif randx1==4
            Coordi_authentic(16,:)  = Tag_F(NumSub_NC(16),features);
        else
            Coordi_NC(16,:)  = Tag_G(NumSub_NC(16),features);
        end
        
        % % %%% Testing %%%%%%
        % %
        % %%% For Extraction %%%%%%
        %
        %                 %% Testing %%%%%%
        %                 %
        % %%% For Extraction %%%%%%
        Coordi_authentic_t = Tag_A(NumSub_authentic_t,features);
        Coordi_counterfeit_t  = Tag_B(NumSub_counterfeit_t,features);
        
        
        Am = Coordi_authentic;   % Define training
        Bm = Coordi_counterfeit;
        
        Am_t = Coordi_authentic_t;
        Bm_t = Coordi_counterfeit_t;
        
        
        
        Label_train(1:size(Am,1),:) = {'authentic'};
        Label_train(size(Am,1)+1:size(Am,1)+size(Bm,1),:) = {'counterfeit'};
        
        
        %%%%%%%%%%%%
      
            Data_train = [Am;Bm];
    
            Data_test = [Am_t;Bm_t];
            
            SVMModel = fitcsvm(Data_train,Label_train,'KernelScale','auto','Standardize',true, 'OutlierFraction',0.01);
            label(:,fold) = predict(SVMModel,Data_test);
            Loss(fold,kk) = sum(~strcmp (Label_Exp, label(:,fold)))/size(label,1);
            
        end
    end
    
    Loss_mean(mento) =  mean(Loss);
Accuracy = mean(1-Loss_mean);%Get the classification accuracy under different feature numbers, from large to small.
close(f)
