clear 
clc all

tag = load(sprintf('..\demo\\HH9654_1.mat'));
f = cell2mat(struct2cell(tag));

AHH9662_1 = f;% Responding signal

ax_normHH9662_1 = Normalization(f);% normalized signal

yHH9662_1 = MatchFilter(ax_normHH9662_1);%expected signal

noiseHH9662_1 = ax_normHH9662_1-yHH9662_1;%noise signal from 

