function ax_norm=Normalization(x)
f=x;
opts = statset('Display','final');
 [idx,C] = kmeans(f,2,'Distance','cityblock','Replicates',100,'Options',opts);
if C(1)>C(2)
 nMax = C(1); nMin = C(2);
else
 nMax = C(2); nMin = C(1);
end
s=((f - nMin)/(nMax - nMin));
 ax_norm=s;
end