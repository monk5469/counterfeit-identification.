clc all
clear all
Tag = load(sprintf('...\\demo\\hh9662_1.mat'));
Tag = cell2mat(struct2cell(Tag));
f = Tag;
u = mean(f);% Mean of the EPC
V = var(f);%Variance of the EPC
sh=histogram(f,10);
counts = sh.Values;
for ii=1:10
    s=counts(ii)/7001;
    ss(ii)=s*log2(s);
end
S=-sum(ss);% Shannon entropy of the EPC
for t = 1:length(f)
    cen(t) = (f(t)-u)^2;
end
CM = sum(cen)/length(f);% Second central moment of the EPC
K = kurtosis(f);% Kurtosis coefficient of the EPC
Skewness = skewness(f);% Deflection of the EPC
c = xcorr(f);
C = c(7001);%Maximum cross-correlation of EPC


